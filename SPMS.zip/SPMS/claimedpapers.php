<?php

  session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $conn = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }
   //echo "Connected successfully";
$email_address = $_SESSION['email_address'];

$sql ="SELECT * 
FROM Decide natural join Submit_to_journal natural join Journal_has_editor natural join Paper
WHERE decision IS NULL and paper_id not in (SELECT paper_id from Assign)";

$result = mysqli_query($conn, $sql);

$sql1 ="SELECT name
FROM User  
WHERE email_address = '$email_address'";

$result1 = mysqli_query($conn, $sql1);
$row1 = mysqli_fetch_array($result1);


$sql2 ="SELECT distinct paper_id,title, submission_date_j 
FROM Paper natural join Assign natural join Submit_to_journal natural join Journal_has_editor natural join Decide 
WHERE decision is null and editor_email_address = '$email_address'";

$result2 = mysqli_query($conn, $sql2);
?>

<html>
<head>
	<title>Scientific Paper Management System</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="stylesheet.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">

	<style type="text/css">
		td a {
			display: block;
			text-decoration: none;
			color: black;
		}


	</style>
</head>

<body>

	<script type="text/javascript">
		function openAdvancedSearch(id) {
			var prefix = "a";
			var searchid = prefix.concat(id);
			var x = document.getElementById(searchid);
			if(x.style.display == "none")
				x.style.display = "block";
			else
				x.style.display = "none";
		}

	</script>

	<header>
		<h1>Scientific Paper Management System</h1>
		<p>Easiest way to read and publish scientific papers.</p>
	</header>

	<ul class="navlist">
		<li class="navitem"><a href="editorHomepage.php">HOME</a></li>
		<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
		<li class="navitem"><a href="journals.php">JOURNALS</a></li>
		<li class="navitem"><a href="submittedpapers.php">SUBMITTED PAPERS</a></li>
		<li class="navitem"><a href="claimedpapers.php"  id="activepage">CLAIMED PAPERS</a></li>
		<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
		<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
	</ul>


	<div class="search" style="display: block;">
		<button style="float: right;">Search</button>
		<input style="float: right;" type="text" name="Search">
		
	</div>

	<div class="sidecol">

		<ul>
			<li id="s1" onclick="openAdvancedSearch(this.id)">Search by title</li>
			<ul class="hiddensearch" id="as1">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s2" onclick="openAdvancedSearch(this.id)">Search by author</li>
			<ul class="hiddensearch" id="as2">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s3" onclick="openAdvancedSearch(this.id)">Search by conference</li>
			<ul class="hiddensearch" id="as3">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s4" onclick="openAdvancedSearch(this.id)">Search by institution</li>
			<ul class="hiddensearch" id="as4">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>

	</div>

	<div class="maincol">


		

<div class="container">
    <div class="row">
        <div class="col-md-12" style="margin-top: 50px">

            <table id="example" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>Paper</th>
                    <th>Submission Date</th>
                    <th>Assign Reviewers</th>
                </tr>
                </thead>
                <?php
                while($row = mysqli_fetch_array($result))
                {
                    echo '  
                               <tr>  
                                    <td><a href="">'.$row["title"].'</a></td>  
                                    <td>'.$row["submission_date_j"].'</td>  
                                    <td align="center"><form action="assignReviewer.php" method="post">
                                         <input type="hidden" value="'.$row['paper_id'].'" name="assign_button">
                                        <input type="submit" value="Assign" class="btn-success">
                                    </form>
                                    </td>
                               </tr>  
                               ';
                }
                ?>
            </table>

            <hr>
            <table id="example-1" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>Paper</th>
                    <th>Submission Date</th>
                    <th>Read Review</th>
                    <th>Accept/Reject</th>
                </tr>
                </thead>
                <?php
                while($row2 = mysqli_fetch_array($result2))
                {

                    echo '  
                               <tr>  
                                    <td><a href="">'.$row2["title"].'</a></td>  
                                    <td>'.$row2["submission_date_j"].'</td>  
                                    
                                    <td align="center"><form action="readReview.php" method="POST">
                                         <input type="hidden" value="'.$row2['paper_id'].'" name="read_review_button">
                                        <input type="submit" value="Review" class="btn-info">
                                        </form>
                                        </td>
                                        
                                    <td align="center"><form action="controller.php" method="POST">
                                         <input type="hidden" value="'.$row2['paper_id'].'" name="accept_button">
                                        <input type="submit" value="Accept" class="btn-success">
                                        <input type="hidden" value="'.$row2['paper_id'].'" name="reject_button">
                                        <input type="submit" value="Reject" class="btn-danger">
                                    </form>
                                    </td>
                                    
                               </tr>  
                               ';
                }
                ?>
            </table>








        </div>
    </div>
</div>


	</div>


<div class="footer">
  <p></p>
</div>

</body>


</html>