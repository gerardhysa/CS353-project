<?php

  session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $conn = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }
   //echo "Connected successfully";
   $success = TRUE;
   
   //Get paper information
   $paper_id = $_GET["paper_id"];
   $paper_sql = "SELECT * FROM Paper WHERE paper_id='$paper_id'";
   $paper_result = mysqli_query($conn, $paper_sql);
   $row = mysqli_fetch_array($paper_result);
   $title = $row['title'];
   $abstract = $row['abstract'];
   $date_of_publication = $row['date_of_publication'];
   $email_address = $_SESSION['email_address'];


   //Read auhtors from another table
   $author_sql = "SELECT * FROM Paper NATURAL JOIN Write_paper NATURAL JOIN User NATURAL JOIN Has_author WHERE paper_id='$paper_id' AND email_address=author_email_address";
   $author_result = mysqli_query($conn, $author_sql);


   //Read conferences from another table



   //See comments 
   $comment_sql= "SELECT paper_id,email_address,name,lastname,comment_content FROM Paper NATURAL JOIN Comment NATURAL JOIN User WHERE paper_id='$paper_id'";
   $comment_result = mysqli_query($conn, $comment_sql);

   //Add the comment to db
   if(isset($_POST['sendcomment']))
   {
   	$yourcomment = $_POST['comment'];
   	//echo "<p>Your comment: ".$yourcomment." ".$paper_id."</p>";
   	$sql = "INSERT INTO Comment(email_address,paper_id,comment_content) VALUES('$email_address','$paper_id','$yourcomment')";
   	$result = mysqli_query($conn, $sql);
   	//echo $conn->error;
	header("Refresh:0");

   }
  

?>

<html>
<head>
	<title>Scientific Paper Management System</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="stylesheet.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">

	<style type="text/css">
		
		.infobox {
		  width: 90%;
		  padding: 5%;
		  margin: auto;
		  
		  background: #FFFFFF;
		  /*max-width: 360px;*/
		  margin: 5% auto;
		  z-index: -1;
		  text-align: left;
		  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
		}

		textarea {
			width: 100%;
			height: 50px;
			margin: auto;
		}

		.commentsec {
			width: 70%;
			background-color: rgba(0,0,0,0.5);
			margin: auto;
			padding: 3%;
			color: white;
			height: 370px;
			box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
		}

		.commentfeed{
			position: relative;
			overflow-y: scroll;
			height: 100px;
		}

	</style>

</head>

<body>

	<header style="text-align: left;">
		<h1>SPMS</h1>
		<p>Scientific Paper Management System</p>
	</header>

	<?php
		$role_sql = "SELECT * FROM User_role WHERE email_address='$email_address'";
		$role_result = mysqli_query($conn,$role_sql);
		$row = mysqli_fetch_array($role_result);
		if($row['role'] == 'subscriber')
		{
			echo '
				<ul class="navlist">
					<li class="navitem"><a href="userHomepage.php">HOME</a></li>
					<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
					<li class="navitem"><a href="journals.php">JOURNALS</a></li>
					<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
					<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
				</ul>

			';
		}
		else if($row['role'] == 'author')
		{
			echo '
				<ul class="navlist">
					<li class="navitem"><a href="authorHomepage.php">HOME</a></li>
					<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
					<li class="navitem"><a href="journals.php">JOURNALS</a></li>
					<li class="navitem"><a href="mypapers.php">MY PAPERS</a></li>
					<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
					<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
				</ul>

			';			
		}
	?>




	<div class="infobox">

		  
		<!--Print the information-->
		<?php
			echo "<h2>Title:   ".$title."</h2>";
			echo "<p>Publish Date:   ".$date_of_publication."</p>";
			echo "<p>Abstract:   ".$abstract."</p>";
		?>

		<br><br>

	<h4>Authors:  </h4>
	<!--Print the authors and institutions in table-->
	<table id="mytable" style="width: 70%; margin: auto;">

		  <tr>
		    <th>AUTHOR NAME</th>
		    <th>INSTITUTION NAME</th>
		  </tr>
		<?php
	        if ($author_result->num_rows > 0) {
	            // output data of each row
	            while($row = mysqli_fetch_array($author_result)) {
	            	echo "<tr>";
	            	$temp = "<a href='author.php?author_id=".$row["author_id"]."'>";
	                echo "<td>".$temp.$row["name"]." ".$row["lastname"]."</a></td><td>".$temp.$row["institution_name"]."</a></td>";
	                echo "</tr>";
	            }
	            
	         }
	         else
	         {
	            echo "No papers";
	         }
	    ?>
</table>



		<br><br>
		<div class="commentsec">
			<h4>COMMENTS</h4>
			<!--Comment Feed-->
			<div class="commentfeed">

				<p>
			<?php
				if($comment_result->num_rows > 0)
				{
					while ($row = mysqli_fetch_array($comment_result))
					{
						echo $row['name']." ".$row['lastname']."  :    ".$row['comment_content']."<br><br>";
					}
				}
			?>
		</p>
		</div>

		<br><br><br>
			<label>Enter Your Comment<br></label>
			<form action="" method="post" id="commentform" style="margin: auto;">
				<textarea name="comment" form="commentform" ></textarea>
				<input style="display: block; margin: auto;" type="submit" name="sendcomment" value="Submit" />
			</form>
			

		</div>


	</div>






<div class="footer">
  <p></p>
</div>

</body>


</html>