<?php

  session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $conn = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }
   //echo "Connected successfully";
   $email_address = $_SESSION['email_address'];

$sql = "SELECT ISSN,journal_name FROM Subscribe NATURAL JOIN Journal WHERE email_address = '$email_address'";
$result = mysqli_query($conn, $sql);

if(isset($_POST['unsub-button'])){


    $ISSNToUnSubscribe = mysqli_real_escape_string($conn, $_POST['unsub-button']);
    //echo $ISSNToUnSubscribe."  ".$email_address;
    
    unSubscribe($conn,$email_address,$ISSNToUnSubscribe);
}

function unSubscribe($conn, $email_address,$ISSNToUnSubscribe){

   //echo $rowToUnSubscribe;

	$sql = "DELETE FROM Subscribe WHERE email_address = '$email_address' AND ISSN ='$ISSNToUnSubscribe'";

    $res = mysqli_query($conn, $sql);
    header("location:subscriptions.php");
}



?>

<html>
<head>
	<title>Scientific Paper Management System</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="stylesheet.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">

	<style type="text/css">
		td a {
			display: block;
			text-decoration: none;
			color: black;
		}


	</style>
</head>

<body>

	<script type="text/javascript">
		function openAdvancedSearch(id) {
			var prefix = "a";
			var searchid = prefix.concat(id);
			var x = document.getElementById(searchid);
			if(x.style.display == "none")
				x.style.display = "block";
			else
				x.style.display = "none";
		}

	</script>

	<header>
		<h1>Scientific Paper Management System</h1>
		<p>Easiest way to read and publish scientific papers.</p>
	</header>

	<?php
		$role_sql = "SELECT * FROM User_role WHERE email_address='$email_address'";
		$role_result = mysqli_query($conn,$role_sql);
		$row = mysqli_fetch_array($role_result);
		if($row['role'] == 'subscriber')
		{
			echo '
				<ul class="navlist">
					<li class="navitem"><a href="userHomepage.php">HOME</a></li>
					<li class="navitem"><a href="subscriptions.php" id="activepage">MY SUBSCRIPTIONS</a></li>
					<li class="navitem"><a href="journals.php">JOURNALS</a></li>
					<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
					<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
				</ul>

			';
		}
		else if($row['role'] == 'author')
		{
			echo '
				<ul class="navlist">
					<li class="navitem"><a href="authorHomepage.php">HOME</a></li>
					<li class="navitem"><a href="subscriptions.php" id="activepage">MY SUBSCRIPTIONS</a></li>
					<li class="navitem"><a href="journals.php">JOURNALS</a></li>
					<li class="navitem"><a href="mypapers.php">MY PAPERS</a></li>
					<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
					<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
				</ul>

			';			
		}
		else if($row['role']=='editor')
		{
			echo '
					<ul class="navlist">
		<li class="navitem"><a href="editorHomepage.php">HOME</a></li>
		<li class="navitem"><a href="subscriptions.php" id="activepage">MY SUBSCRIPTIONS</a></li>
		<li class="navitem"><a href="journals.php">JOURNALS</a></li>
		<li class="navitem"><a href="submittedpapers.php">SUBMITTED PAPERS</a></li>
		<li class="navitem"><a href="claimedpapers.php">CLAIMED PAPERS</a></li>
		<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
		<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
	</ul>
			';
		}
	?>


	<div class="search" style="display: block;">
		<button style="float: right;">Search</button>
		<input style="float: right;" type="text" name="Search">
		
	</div>

	<div class="sidecol">

		<ul>
			<li id="s1" onclick="openAdvancedSearch(this.id)">Search by title</li>
			<ul class="hiddensearch" id="as1">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s2" onclick="openAdvancedSearch(this.id)">Search by author</li>
			<ul class="hiddensearch" id="as2">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s3" onclick="openAdvancedSearch(this.id)">Search by conference</li>
			<ul class="hiddensearch" id="as3">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s4" onclick="openAdvancedSearch(this.id)">Search by institution</li>
			<ul class="hiddensearch" id="as4">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>

	</div>

	<div class="maincol">

		<table id="mytable">
		  <tr>
		    <th>JOURNAL</th>
		    <th>SUBSCRIBE</th>
		  </tr>

		<?php

			while($row = mysqli_fetch_array($result))
                {
                	echo "<tr>";
	            	$temp = "<a href='journal.php?ISSN=".$row["ISSN"]."'>";
	                echo "<td>".$temp.$row["journal_name"]."</a></td>";
	                echo '<td align="center"><form action="" method="post">
                                         <input type="hidden" value="'.$row['ISSN'].'" name="unsub-button">
                                        <input type="submit" value="UnSubscribe" class="btn-success">
                                    </form>
                                    </td>';
	                echo "</tr>";

                }

	    ?>


		</table>


	</div>


<div class="footer">
  <p></p>
</div>

</body>


</html>