<?php
session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $conn = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }
   //echo "Connected successfully";
$email_address = $_SESSION['email_address'];

$sql ="SELECT name, email_address 
from User NATURAL JOIN User_role 
where role = 'reviewer' and email_address not in ( SELECT assigned_reviewed from assigned_and_reviewed where  no > 5)";

$result = mysqli_query($conn, $sql);


$sql1 ="SELECT name
FROM User  
WHERE email_address = '$email_address'";

$result1 = mysqli_query($conn, $sql1);
$row1 = mysqli_fetch_array($result1);

if(isset($_POST['assign_button'])) {

    $paper_id = intval($_POST['assign_button']);

}



if(isset($_POST["submit_reviewer"])) {

    $paper_id = intval($_POST['submit_reviewer']);

}




if(isset($_POST["framework"]))
{

    $email_address = $_SESSION['email_address'];

    $count = 0;

    foreach($_POST["framework"] as $row) {
        ++$count;
    }
    if($count <= 3) {

        foreach ($_POST["framework"] as $row) {
            $framework = $row;
            $query = "INSERT INTO Assign(reviewer_email_address,paper_id,editor_email_address)
              VALUES('$framework','$paper_id','$email_address')";

            $query1 = "INSERT INTO Review(reviewer_email_address,paper_id,review_content,review_grade)
              VALUES('$framework','$paper_id',NULL, NULL )";

            $res = mysqli_query($conn, $query);
            $res1 = mysqli_query($conn, $query1);

        }
        echo 'Data Inserted';
    }else{
        echo 'You cannot assign more than 3 reviewers to a paper';
    }
}



?>



<!doctype html>
<html lang="en">
<head>
    <title>Scientific Paper Management System</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="stylesheet.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">

    <script>
        $(document).ready(function(){
            $('#framework').multiselect({
                nonSelectedText: 'Select Reviewer',
                enableFiltering: true,
                enableCaseInsensitiveFiltering: true,
                buttonWidth:'400px'
            });

            $('#framework_form').on('submit', function(event){
                event.preventDefault();
                var form_data = $(this).serialize();
                $.ajax({
                    url:"insertReviewers.php",
                    method:"POST",
                    data:form_data,
                    success:function(data)
                    {
                        $('#framework option:selected').each(function(){
                            $(this).prop('selected', false);
                        });
                        $('#framework').multiselect('refresh');
                        alert(data);
                    }
                });
            });


        });
    </script>


</head>

<body>

        <header>
        <h1>Scientific Paper Management System</h1>
        <p>Easiest way to read and publish scientific papers.</p>
    </header>

    <ul class="navlist">
        <li class="navitem"><a href="editorHomepage.php">HOME</a></li>
        <li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
        <li class="navitem"><a href="journals.php">JOURNALS</a></li>
        <li class="navitem"><a href="submittedpapers.php">SUBMITTED PAPERS</a></li>
        <li class="navitem"><a href="claimedpapers.php"  id="activepage">CLAIMED PAPERS</a></li>
        <li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
        <li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
    </ul>


<div class="container" style="width:600px;">

    <br /><br />

    <form method="post" id="framework_form">
        <div class="form-group">
            <label>Select Reviewers</label>
            <select id="framework" name="framework[]" multiple class="form-control" >
                <?php
                while($row = mysqli_fetch_array($result)){
                    echo '
                        <option value="'.$row['email_address'].'">'.$row['name'].'</option>
                    
                ';}
                echo '
                
            </select>
        </div>
        <div class="form-group">
            <input type="hidden" value="'.$paper_id.'" name="submit_reviewer">
            <input type="submit" class="btn btn-info" name="submit_reviewer" value="Submit"/>
        </div>
        ';?>
    </form>

    <br />
</div>




<br />



</body>
</html>


