<?php

  session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $conn = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }
   //echo "Connected successfully";
$email_address = $_SESSION['email_address'];

$sql ="SELECT * 
FROM Submitted_editor_J 
WHERE role = 'author'";

$result = mysqli_query($conn, $sql);

$sql1 ="SELECT name
FROM User  
WHERE email_address = '$email_address'";

$result1 = mysqli_query($conn, $sql1);
$row1 = mysqli_fetch_array($result1);

if(isset($_POST['claim_button'])){

	$claimed_paper_id = mysqli_real_escape_string($conn, $_POST['claim_button']);
    //$rowToClaim = intval($_POST['claim_button']);
    $email_address = $_SESSION['email_address'];
    claimPaper($conn, $email_address,$claimed_paper_id);
}

function claimPaper($conn,$email_address,$claimed_paper_id){

    $sql = "INSERT INTO Decide(editor_email_address,paper_id,decision)
VALUES('$email_address','$claimed_paper_id',NULL )";

    $res = mysqli_query($conn, $sql);

    header("location:submittedPapers.php");


}

if(isset($_POST['update_profile'])){

    updateProfile($conn);
}

?>

<html>
<head>
	<title>Scientific Paper Management System</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="stylesheet.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">

	<style type="text/css">
		td a {
			display: block;
			text-decoration: none;
			color: black;
		}


	</style>
</head>

<body>

	<script type="text/javascript">
		function openAdvancedSearch(id) {
			var prefix = "a";
			var searchid = prefix.concat(id);
			var x = document.getElementById(searchid);
			if(x.style.display == "none")
				x.style.display = "block";
			else
				x.style.display = "none";
		}

	</script>

	<header>
		<h1>Scientific Paper Management System</h1>
		<p>Easiest way to read and publish scientific papers.</p>
	</header>

	<ul class="navlist">
		<li class="navitem"><a href="editorHomepage.php">HOME</a></li>
		<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
		<li class="navitem"><a href="journals.php">JOURNALS</a></li>
		<li class="navitem"><a href="submittedpapers.php"  id="activepage">SUBMITTED PAPERS</a></li>
		<li class="navitem"><a href="claimedpapers.php">CLAIMED PAPERS</a></li>
		<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
		<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
	</ul>


	<div class="search" style="display: block;">
		<button style="float: right;">Search</button>
		<input style="float: right;" type="text" name="Search">
		
	</div>

	<div class="sidecol">

		<ul>
			<li id="s1" onclick="openAdvancedSearch(this.id)">Search by title</li>
			<ul class="hiddensearch" id="as1">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s2" onclick="openAdvancedSearch(this.id)">Search by author</li>
			<ul class="hiddensearch" id="as2">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s3" onclick="openAdvancedSearch(this.id)">Search by conference</li>
			<ul class="hiddensearch" id="as3">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s4" onclick="openAdvancedSearch(this.id)">Search by institution</li>
			<ul class="hiddensearch" id="as4">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>

	</div>

	<div class="maincol">


		


		<table id="mytable">
        <tr>
            <th>Paper</th>
            <th>Author</th>
            <th>Institution</th>
            <th>Submission Date</th>
            <th>Claim</th>
        </tr>
                <?php
                $conn->error;
                if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_array($result))
                {
                    echo '  
                               <tr>  
                                    <td><a href="">'.$row["title"].'</a></td>  
                                    <td><a href="">'.$row["name"].'</a></td>  
                                    <td><a href="">'.$row["institution_name"].'</a></td>   
                                    <td>'.$row["submission_date_j"].'</td>  
                                    <td align="center"><form action="" method="post">
                                         <input type="hidden" value="'.$row['paper_id'].'" name="claim_button">
                                        <input type="submit" value="Claim" class="btn-success">
                                    </form>
                                    </td>
                               </tr>  
                               ';
                }
            }
            

                ?>


		</table>


	</div>


<div class="footer">
  <p></p>
</div>

</body>


</html>