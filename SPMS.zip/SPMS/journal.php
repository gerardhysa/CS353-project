<?php

  session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $conn = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }
   //echo "Connected successfully";
   $success = TRUE;
   $email_address = $_SESSION['email_address'];
   
   //Get journal information
   $ISSN = $_GET["ISSN"];
   $journal_sql = "SELECT * FROM Journal";
   $journal_result = mysqli_query($conn, $journal_sql);
   $row = mysqli_fetch_array($journal_result);
   $journal_name = $row['journal_name'];
   $year_of_publication = $row['year_of_publication'];


  

?>

<html>
<head>
	<title>Scientific Paper Management System</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="stylesheet.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">

	<style type="text/css">
		
		.infobox {
		  width: 90%;
		  padding: 2%;
		  margin: auto;
		  position: relative;
		  
		  background: #FFFFFF;
		  /*max-width: 360px;*/
		  margin: 5% auto;
		  z-index: -1;
		  text-align: center;
		  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
		}

		textarea {
			width: 80%;
			height: 50px;
			margin: auto;
		}

		.commentsec {
			width: 70%;
			background-color: rgba(0,0,0,0.5);
			margin: auto;
			padding: 3%;
			color: white;
			height: 300px;
			box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
		}

		.commentfeed{
			position: relative;
			overflow-y: scroll;
			height: 50px;
		}

	</style>

</head>

<body>

	<header>
		<h1>Scientific Paper Management System</h1>
		<p>Easiest way to read and publish scientific papers.</p>
	</header>

	<?php
		$role_sql = "SELECT * FROM User_role WHERE email_address='$email_address'";
		$role_result = mysqli_query($conn,$role_sql);
		$row = mysqli_fetch_array($role_result);
		if($row['role'] == 'subscriber')
		{
			echo '
				<ul class="navlist">
					<li class="navitem"><a href="userHomepage.php">HOME</a></li>
					<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
					<li class="navitem"><a href="journals.php">JOURNALS</a></li>
					<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
					<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
				</ul>

			';
		}
		else if($row['role'] == 'author')
		{
			echo '
				<ul class="navlist">
					<li class="navitem"><a href="authorHomepage.php">HOME</a></li>
					<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
					<li class="navitem"><a href="journals.php">JOURNALS</a></li>
					<li class="navitem"><a href="mypapers.php">MY PAPERS</a></li>
					<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
					<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
				</ul>

			';			
		}
	?>



	<div class="infobox">

		<!--Print the information-->
		<?php
			echo "<h1>".$journal_name."</h1>";
			echo "<p style='text-align: right;'>".$year_of_publication."</p>";
		?>

		<br><br><br>




	</div>






<div class="footer">
  <p></p>
</div>

</body>


</html>