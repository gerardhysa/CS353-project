<?php

  session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $conn = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }
   //echo "Connected successfully";
 /*
   $sql ="SELECT title,name,institution_name,journal_name,date_of_publication 
FROM Paper NATURAL JOIN Write_paper NATURAL JOIN User NATURAL JOIN Has_author NATURAL JOIN Submit_to_journal NATURAL JOIN Journal NATURAL JOIN User_role 
WHERE role = 'author'";*/
$sql = "SELECT * FROM Paper NATURAL JOIN Write_paper NATURAL JOIN User NATURAL JOIN Has_author WHERE author_email_address=email_address";
$result = mysqli_query($conn, $sql);

?>

<html>
<head>
	<title>Scientific Paper Management System</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="stylesheet.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">

	<style type="text/css">
		td a {
			display: block;
			text-decoration: none;
			color: black;
		}


	</style>
</head>

<body>

	<script type="text/javascript">
		function openAdvancedSearch(id) {
			var prefix = "a";
			var searchid = prefix.concat(id);
			var x = document.getElementById(searchid);
			if(x.style.display == "none")
				x.style.display = "block";
			else
				x.style.display = "none";
		}

	</script>

	<header>
		<h1>Scientific Paper Management System</h1>
		<p>Easiest way to read and publish scientific papers.</p>
	</header>

	<ul class="navlist">
		<li class="navitem"><a href="userHomepage.php" id="activepage">HOME</a></li>
		<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
		<li class="navitem"><a href="journals.php">JOURNALS</a></li>
		<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
		<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
	</ul>

	<div class="search" style="display: block;">
		<button style="float: right;">Search</button>
		<input style="float: right;" type="text" name="Search">
		
	</div>

	<div class="sidecol">

		<ul>
			<li id="s1" onclick="openAdvancedSearch(this.id)">Search by title</li>
			<ul class="hiddensearch" id="as1">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s2" onclick="openAdvancedSearch(this.id)">Search by author</li>
			<ul class="hiddensearch" id="as2">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s3" onclick="openAdvancedSearch(this.id)">Search by conference</li>
			<ul class="hiddensearch" id="as3">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s4" onclick="openAdvancedSearch(this.id)">Search by institution</li>
			<ul class="hiddensearch" id="as4">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>

	</div>

	<div class="maincol">

		<table id="mytable">
		  <tr>
		    <th>PAPER</th>
		    <th>AUTHOR</th>
		    <th>INSTITUTION</th>
		    <th>JOURNAL</th>
		    <th>PUBLISH DATE</th>
		  </tr>

		<?php

			while($row = mysqli_fetch_array($result))
                {
                	echo "<tr>";
	            	$temp = "<a href='paper.php?paper_id=".$row["paper_id"]."'>";
	                echo "<td>".$temp.$row["title"]."</a></td><td>".$temp.$row["name"]." ".$row['lastname']."</a></td><td>".$temp.$row['institution_name']."</a></td><td>".$temp.$row['journal_name']."</a></td><td>".$temp.$row["date_of_publication"]."</a></td>";
	                echo "</tr>";

                }

	    ?>


		</table>


	</div>


<div class="footer">
  <p></p>
</div>

</body>


</html>