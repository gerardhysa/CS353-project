<?php

include "session.php";
session_start();

$_SESSION['email_address'] = null;
unset($_SESSION['email_address']);
session_destroy();
header("Location: login.php");


?>