<?php

  session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $conn = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }
   //echo "Connected successfully";
   $success = TRUE;
   
   //Get user information
   $email_address = $_SESSION['email_address'];
   $password = $_SESSION['password'];

   //echo "<p>User:  ".$email_address."   ".$password."</p>";
   $sql = "SELECT * FROM User WHERE email_address = '$email_address' and password = '$password'";
   $result = mysqli_query($conn,$sql);
   $row = mysqli_fetch_array($result);
   $name = $row['name'];
   $lastname = $row['lastname'];
   $bdate = $row['date_of_birth'];

   if(isset($_POST['update_profile'])){
    updateProfile($conn);
}
function updateProfile($conn){
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $lastname = mysqli_real_escape_string($conn, $_POST['lastname']);
    $date_of_birth = mysqli_real_escape_string($conn, $_POST['date_of_birth']);
    $email_address = mysqli_real_escape_string($conn, $_POST['email_address']);
    $sql = "UPDATE User SET name = '$name', lastname = '$lastname',  date_of_birth = '$date_of_birth' WHERE email_address = '$email_address'";
    $res = mysqli_query($conn, $sql);
    header("location:userProfile.php");
}

?>


<html>
<head>
	<title>Scientific Paper Management System</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="stylesheet.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">
<style>

* {
	box-sizing: border-box;
}

body {
	font-family: 'Roboto', sans-serif;
	font-weight: 300;
	color: black;
	/*background-color: #666666;*/
	background-color: #afadad;
	padding: 0;
	margin: 0;
	/*background-image: url("images/login_back.png");*/
}

.main {
	/*color: white;*/
	width: 80%;
	height: 80%;
	margin: auto;
	margin-top: 5%;
	background-color: rgba(0,0,0, 0.7);
}

.leftside {
	color: #FF9900;
	padding: 50px;
	float: left;
	width: 512px;
	height: 580px;
}

.rightside {
	float: left;
	width: 50%;
	height: 100%;
	background-color: rgb(255,153,0);

}


.signup-page {
  width: 360px;
  padding: 10% 0 0;
  margin: auto;
}
.form {
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 360px;
  margin: 0 auto 40px;
  padding: 30px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 7px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
  color: black;
}
.form .submitbutton {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #FF9900;
  width: 100%;
  border: 0;
  padding: 15px;
  color: #FFFFFF;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form .submitbutton:hover,.form .submitbutton:active,.form .submitbutton:focus {
  background: #ac6700;
}
.form .message {
  margin: 15px 0 0;
  color: #b3b3b3;
  font-size: 12px;
}
.form .message a {
  color: #4CAF50;
  text-decoration: none;
}
.form .register-form {
  display: block;
}
.container {
  position: relative;
  z-index: 1;
  max-width: 300px;
  margin: 0 auto;
}
.container:before, .container:after {
  content: "";
  display: block;
  clear: both;
}
.container .info {
  margin: 50px auto;
  text-align: center;
}
.container .info h1 {
  margin: 0 0 15px;
  padding: 0;
  font-size: 36px;
  font-weight: 300;
  color: #1a1a1a;
}
.container .info span {
  color: #4d4d4d;
  font-size: 12px;
}
.container .info span a {
  color: #000000;
  text-decoration: none;
}
.container .info span .fa {
  color: #EF3B3A;
}

.imageholder img {
	width:150px;
    height:150px; 
    float:left; 
    border-radius:50%; 
    margin-right:25px;
}

.imageholder
{
	display: inline-block;
	width: 70%;
	border: 2px solid black;

}

</style>

</head>

<body>

	<header>
		<h1>Scientific Paper Management System</h1>
		<p>Easiest way to read and publish scientific papers.</p>
	</header>


	<?php
		$role_sql = "SELECT * FROM User_role WHERE email_address='$email_address'";
		$role_result = mysqli_query($conn,$role_sql);
		$row = mysqli_fetch_array($role_result);
		if($row['role'] == 'subscriber')
		{
			echo '
				<ul class="navlist">
					<li class="navitem"><a href="userHomepage.php">HOME</a></li>
					<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
					<li class="navitem"><a href="journals.php">JOURNALS</a></li>
					<li class="navitem"><a href="userProfile.php" id="activepage">MY PROFILE</a></li>
					<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
				</ul>

			';
		}
		else if($row['role'] == 'author')
		{
			echo '
				<ul class="navlist">
					<li class="navitem"><a href="authorHomepage.php">HOME</a></li>
					<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
					<li class="navitem"><a href="journals.php">JOURNALS</a></li>
					<li class="navitem"><a href="mypapers.php">MY PAPERS</a></li>
					<li class="navitem"><a href="userProfile.php" id="activepage">MY PROFILE</a></li>
					<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
				</ul>

			';			
		}
		else if($row['role']=='editor')
		{
			echo '
					<ul class="navlist">
		<li class="navitem"><a href="editorHomepage.php">HOME</a></li>
		<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
		<li class="navitem"><a href="journals.php">JOURNALS</a></li>
		<li class="navitem"><a href="submittedpapers.php">SUBMITTED PAPERS</a></li>
		<li class="navitem"><a href="claimedpapers.php">CLAIMED PAPERS</a></li>
		<li class="navitem"><a href="userProfile.php"  id="activepage">MY PROFILE</a></li>
		<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
	</ul>
			';
		}
	?>


	<div class="main">

		<div class="leftside">

<!--
			<?php
			/*
            echo '
		        <div class="imageholder">
		            <img src="data:image/jpeg;base64,<?php echo base64_encode( $row1 ); ?>">
		           	<form action="" method="post" enctype="multipart/form-data">
		        Select image to upload:
		        <input type="file" name="image"/>
		        <input class="btn-primary" type="submit" name="avatar" value="UPLOAD"/>
		    </form>';*/
			?>
-->


		</div>



		<div class="rightside">

			<div class="signup-page">
			  <div class="form">
			    <form class="register-form" action = "" method = "post">
			    	<?php
			    		echo '<input type="text" name="name" value="'.$name.'"/>';
			    		echo '<input type="text" name="lastname" value="'.$lastname.'"/>';
			    		echo '<input type="text" name="email_address" value="'.$email_address.'"/>';
			    		echo '<input type="text" name="bdate" placeholder="date of birth" value="'.$bdate.'"/>';
			    	?>
			    	<input type="password" placeholder="password" name="password"/>
            		<input type="password" placeholder="confirm password" name="password_confirmation"/>

              <br><br><br>
  			   <input class="submitbutton" name="update_profile" type = "submit" value = " Submit "/><br />
			    </form>
			    
			  </div>
			</div>


		</div>

	</div>

</body>

</html>