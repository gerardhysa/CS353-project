<?php

  session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $conn = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }
   //echo "Connected successfully";
   $success = TRUE;
   $email_address = $_SESSION['email_address'];

   //Read papers
   $paper_sql = "SELECT * FROM Write_paper NATURAL JOIN Paper WHERE author_email_address='$email_address'";
   $paper_result = mysqli_query($conn,$paper_sql);
?>

<html>
<head>
	<title>Scientific Paper Management System</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="stylesheet.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">

	<style type="text/css">
		td a {
			display: block;
			text-decoration: none;
			color: black;
		}


	</style>
</head>

<body>

	<script type="text/javascript">
		function openAdvancedSearch(id) {
			var prefix = "a";
			var searchid = prefix.concat(id);
			var x = document.getElementById(searchid);
			if(x.style.display == "none")
				x.style.display = "block";
			else
				x.style.display = "none";
		}

	</script>

	<header>
		<h1>Scientific Paper Management System</h1>
		<p>Easiest way to read and publish scientific papers.</p>
	</header>

	<?php
		$role_sql = "SELECT * FROM User_role WHERE email_address='$email_address'";
		$role_result = mysqli_query($conn,$role_sql);
		$row = mysqli_fetch_array($role_result);
		if($row['role'] == 'subscriber')
		{
			echo '
				<ul class="navlist">
					<li class="navitem"><a href="userHomepage.php">HOME</a></li>
					<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
					<li class="navitem"><a href="journals.php" id="activepage">JOURNALS</a></li>
					<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
					<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
				</ul>

			';
		}
		else if($row['role'] == 'author')
		{
			echo '
				<ul class="navlist">
					<li class="navitem"><a href="authorHomepage.php">HOME</a></li>
					<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
					<li class="navitem"><a href="journals.php">JOURNALS</a></li>
					<li class="navitem"><a href="mypapers.php" id="activepage">MY PAPERS</a></li>
					<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
					<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
				</ul>

			';			
		}
	?>


	<div class="search" style="display: block;">
		<button style="float: right;">Search</button>
		<input style="float: right;" type="text" name="Search">
		
	</div>

	<div class="sidecol">

		<ul>
			<li id="s1" onclick="openAdvancedSearch(this.id)">Search by title</li>
			<ul class="hiddensearch" id="as1">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s2" onclick="openAdvancedSearch(this.id)">Search by author</li>
			<ul class="hiddensearch" id="as2">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s3" onclick="openAdvancedSearch(this.id)">Search by conference</li>
			<ul class="hiddensearch" id="as3">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s4" onclick="openAdvancedSearch(this.id)">Search by institution</li>
			<ul class="hiddensearch" id="as4">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>

	</div>

	<div class="maincol">


		


		<table id="mytable">
		  <tr>
		    <th>PAPERS</th>
		  </tr>

		  <!--Uplod paper part is in first row-->
		  <tr>
		  	<td><a href='uploadpaper.php' style="text-align: center;">UPLOAD A NEW PAPER</a></td>
		  </tr>
		<?php
	        if ($paper_result->num_rows > 0) {
	            // output data of each row
	            while($row = mysqli_fetch_array($paper_result)) {
	            	echo "<tr>";
	            	if($row['status'] == 'uploaded')
	            		$temp = "<a href='editpaper.php?paper_id=".$row["paper_id"]."'>";
	            	if($row['status'] == 'submitted' || $row['status'] == 'published')
	            		$temp = "<a href='paper.php?paper_id=".$row["paper_id"]."'>";
	                echo "<td>".$temp.$row["title"]."</a></td>";
	                echo "</tr>";
	            }
	            
	         }
	         else
	         {
	            echo "No papers";
	         }
	    ?>


		</table>


	</div>


<div class="footer">
  <p></p>
</div>

</body>


</html>