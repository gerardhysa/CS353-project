<?php

  session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $con = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($con->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }
   //echo "Connected successfully";
   $success = TRUE;
   

   //Read papers
   $author_sql = "SELECT * FROM author NATURAL JOIN has_author";
   $author_result = $con->query($author_sql);
?>

<html>
<head>
	<title>Scientific Paper Management System</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="stylesheet.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">
</head>

<body>

	<script type="text/javascript">
		function openAdvancedSearch(id) {
			var prefix = "a";
			var searchid = prefix.concat(id);
			var x = document.getElementById(searchid);
			if(x.style.display == "none")
				x.style.display = "block";
			else
				x.style.display = "none";
		}

	</script>

	<header>
		<h1>Scientific Paper Management System</h1>
		<p>Easiest way to read and publish scientific papers.</p>
	</header>

	<ul class="navlist">
		<li class="navitem"><a href="index.php">HOME</a></li>
		<li class="navitem"><a href="papers.php">PAPERS</a></li>
		<li class="navitem"><a href="authors.php" id="activepage">AUTHORS</a></li>
		<li class="navitem"><a href="#">INSTITUTIONS</a></li>
		<li class="navitem"><a href="#">CONFERENCES</a></li>
		<li class="navitem"><a href="#">PROFILE</a></li>
	</ul>

	<div class="search" style="display: block;">
		<button style="float: right;">Search</button>
		<input style="float: right;" type="text" name="Search">
		
	</div>

	<div class="sidecol">

		<ul>
			<li id="s1" onclick="openAdvancedSearch(this.id)">Search by title</li>
			<ul class="hiddensearch" id="as1">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s2" onclick="openAdvancedSearch(this.id)">Search by author</li>
			<ul class="hiddensearch" id="as2">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s3" onclick="openAdvancedSearch(this.id)">Search by conference</li>
			<ul class="hiddensearch" id="as3">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>
			<li id="s4" onclick="openAdvancedSearch(this.id)">Search by institution</li>
			<ul class="hiddensearch" id="as4">
				<li>Enter title</li>
				<li>Enter search keys</li>
			</ul>

	</div>


	<div class="maincol">

		<table id="mytable">
		<tr>
	    	<th>AUTHOR NAME</th>
	    	<th>INSTITUTION</th>
	  	</tr>

		<?php
	        if ($author_result->num_rows > 0) {
	            // output data of each row
	            while($row = $author_result->fetch_assoc()) {
	            	echo "<tr>";
	            	$temp = "<a href='author.php?author_id=".$row["author_id"]."'>";
	                echo "<td>".$temp.$row["name"]." ".$row["lastname"]."</a></td><td>".$temp.$row["institution_name"]."</a></td>";
	                echo "</tr>";
	            }
	            
	         }
	         else
	         {
	            echo "No papers";
	         }
	    ?>


		</table>


	</div>







<div class="footer">
  <p></p>
</div>

</body>


</html>