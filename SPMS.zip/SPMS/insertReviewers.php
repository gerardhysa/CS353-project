<?php
session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $conn = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }

if(isset($_POST["submit_reviewer"])) {

    $paper_id = intval($_POST['submit_reviewer']);

}




if(isset($_POST["framework"]))
{

    $email_address = $_SESSION['email_address'];

    $count = 0;

    foreach($_POST["framework"] as $row) {
        ++$count;
    }
    if($count <= 3) {

        foreach ($_POST["framework"] as $row) {
            $framework = $row;
            $query = "INSERT INTO Assign(reviewer_email_address,paper_id,editor_email_address)
              VALUES('$framework','$paper_id','$email_address')";

            $query1 = "INSERT INTO Review(reviewer_email_address,paper_id,review_content,review_grade)
              VALUES('$framework','$paper_id',NULL, NULL )";

            $res = mysqli_query($conn, $query);
            $res1 = mysqli_query($conn, $query1);

        }
        echo 'Data Inserted';
    }else{
        echo 'You cannot assign more than 3 reviewers to a paper';
    }
}

?>