<?php

  session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $conn = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }
   //echo "Connected successfully";
   $success = TRUE;
   $email_address = $_SESSION['email_address'];

   //Get the names of all auhtors
   $author_sql = "SELECT author_email_address,name,lastname FROM User JOIN Author WHERE author_email_address=email_address";
   $author_result = mysqli_query($conn,$author_sql);


   if(isset($_POST['uploadpaper']))
   {
	   	   //Get paper info
	   if(isset($_POST['title']))
	   {
	   	$title = $_POST['title'];
	   }
	   if(isset($_POST['abstract']))
	   {
	   	$abstract = $_POST['abstract'];
	   }
	   $sql = "SELECT MAX(paper_id) AS max_id FROM Paper";
	   $result = mysqli_query($conn,$sql);
	   $row = mysqli_fetch_array($result);
	   $paper_id = intval($row['max_id']) + 1;
	   $date = date("Y/m/d");
	   $status = 'uploaded';
	   $coauthor_email_address = mysqli_real_escape_string($conn,$_POST['authors']);
	   

	   //Upload paper
	   $upload_sql = "INSERT INTO Paper VALUES('$paper_id','$title','$abstract','$date_of_publication',NULL,'$status',NULL)";
	   $upload_result = mysqli_query($conn,$upload_sql);

	   //upload Write_paper
	   $upload_sql = "INSERT INTO Write_paper VALUES('$email_address','$paper_id')";
	   $upload_result = mysqli_query($conn,$upload_sql);
	   $upload_sql = "INSERT INTO Write_paper VALUES('$coauthor_email_address','$paper_id')";
	   $upload_result = mysqli_query($conn,$upload_sql);

	   



	   header("location:mypapers.php");
   }

      if(isset($_POST['submitpaper']))
   {
	   	   //Get paper info
	   if(isset($_POST['title']))
	   {
	   	$title = $_POST['title'];
	   }
	   if(isset($_POST['abstract']))
	   {
	   	$abstract = $_POST['abstract'];
	   }
	   $sql = "SELECT MAX(paper_id) AS max_id FROM Paper";
	   $result = mysqli_query($conn,$sql);
	   $row = mysqli_fetch_array($result);
	   $paper_id = intval($row['max_id']) + 1;
	   $date = date("Y/m/d");
	   $status = 'submitted';
	   $role = mysqli_real_escape_string($conn,$_POST['roles']);

	   //Upload paper
	   $upload_sql = "INSERT INTO Paper VALUES('$paper_id','$title','$abstract','$date_of_publication',NULL,'$status',NULL)";
	   $upload_result = mysqli_query($conn,$upload_sql);

	   //upload Write_paper
	   $upload_sql = "INSERT INTO Write_paper VALUES('$email_address','$paper_id')";
	   $upload_result = mysqli_query($conn,$upload_sql);

	   //Submit to journal only in submit part
	   $journalISSN = mysqli_real_escape_string($conn,$_POST['journals']);
	   $journal_sql = "INSERT INTO Submit_to_journal VALUES('$paper_id','$journalISSN','$date')";

	   header("location:mypapers.php");
   }

?>

<html>
<head>
	<title>Scientific Paper Management System</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="stylesheet.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">

	<style type="text/css">
		
		.infobox {
		  width: 90%;
		  padding: 5%;
		  margin: auto;
		  
		  background: #FFFFFF;
		  /*max-width: 360px;*/
		  margin: 5% auto;
		  z-index: -1;
		  text-align: left;
		  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
		}

		.login-page {
  width: 360px;
  padding: 20% 0 0;
  margin: auto;
}
.form {
	margin: 5% auto;
  position: relative;
  width: 90%;
  z-index: 1;
  background: #FFFFFF;
  padding: 45px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input, textarea {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form .submitbutton, .btn {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #FF9900;
  width: 100%;
  border: 0;
  padding: 15px;
  color: #FFFFFF;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form .submitbutton:hover,.form .submitbutton:active,.form .submitbutton:focus {
  background: #ac6700;
}

.btn:hover,.btn:active,.btn:focus {
  background: #ac6700;
}

.form .register-form {
  display: block;
}
.container {
  position: relative;
  z-index: 1;
  max-width: 300px;
  margin: 0 auto;
}
.container:before, .container:after {
  content: "";
  display: block;
  clear: both;
}
.container .info {
  margin: 50px auto;
  text-align: center;
}
.container .info h1 {
  margin: 0 0 15px;
  padding: 0;
  font-size: 36px;
  font-weight: 300;
  color: #1a1a1a;
}
.container .info span {
  color: #4d4d4d;
  font-size: 12px;
}
.container .info span a {
  color: #000000;
  text-decoration: none;
}
.container .info span .fa {
  color: #EF3B3A;
}


/* Dropdown Button */
.dropbtn {
    background-color: #FF9900;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
    width: 100%;
}

/* Dropdown button on hover & focus */
.dropbtn:hover, .dropbtn:focus {
    background-color: #ac6700;
}

/* The search field */
#myInput {
  border-box: box-sizing;
  background-image: url('searchicon.png');
  background-position: 14px 12px;
  background-repeat: no-repeat;
  font-size: 16px;
  padding: 14px 20px 12px 45px;
  border: none;
  border-bottom: 1px solid #ddd;
}

/* The search field when it gets focus/clicked on */
#myInput:focus {outline: 3px solid #ddd;}

/* The container <div> - needed to position the dropdown content */
.dropdown {
    position: relative;
    display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f6f6f6;
    min-width: 230px;
    border: 1px solid #ddd;
    z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content button {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    border: none;
    width: 100%;
}

/* Change color of dropdown links on hover */
.dropdown-content button:hover {background-color: #f1f1f1}

/* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
.show {display:block;}

.rightform {
	width: 60%;
	float: left;
}


	</style>

	<script type="text/javascript">
		/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

function filterFunction() {
  var input, filter, ul, li, a, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  div = document.getElementById("myDropdown");
  a = div.getElementsByTagName("button");
  for (i = 0; i < a.length; i++) {
    if (a[i].innerHTML.toUpperCase().indexOf(filter) > -1) {
      a[i].style.display = "";
    } else {
      a[i].style.display = "none";
    }
  }
}



	</script>

</head>

<body>

	<header>
		<h1>Scientific Paper Management System</h1>
		<p>Easiest way to read and publish scientific papers.</p>
	</header>

	<?php
		$role_sql = "SELECT * FROM User_role WHERE email_address='$email_address'";
		$role_result = mysqli_query($conn,$role_sql);
		$row = mysqli_fetch_array($role_result);
		if($row['role'] == 'subscriber')
		{
			echo '
				<ul class="navlist">
					<li class="navitem"><a href="userHomepage.php">HOME</a></li>
					<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
					<li class="navitem"><a href="journals.php">JOURNALS</a></li>
					<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
					<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
				</ul>

			';
		}
		else if($row['role'] == 'author')
		{
			echo '
				<ul class="navlist">
					<li class="navitem"><a href="authorHomepage.php">HOME</a></li>
					<li class="navitem"><a href="subscriptions.php">MY SUBSCRIPTIONS</a></li>
					<li class="navitem"><a href="journals.php">JOURNALS</a></li>
					<li class="navitem"><a href="mypapers.php">MY PAPERS</a></li>
					<li class="navitem"><a href="userProfile.php">MY PROFILE</a></li>
					<li class="navitem" style="float: right;"><a href="logout.php">LOG OUT</a></li>
				</ul>

			';			
		}
	?>


    <div class="form">
    <div class="rightform">
	    <form class="register-form" action = "" method = "post" name="uploadform">
	      <input type="text" placeholder="Title" name="title"/>
	      <textarea placeholder="Abstract" name="abstract"></textarea>

			<!--<input type="file" name="selectedfile" />
		  <input class="btn" name="uploadfile" type="submit" />-->
		  	<h6 style="text-align: left;">Coauthors:</h6>
		  	<select name="authors">
		  	<?php
		  	$sql = "SELECT * FROM Author JOIN User WHERE author_email_address=email_address AND author_email_address!='$email_address'";
		  	$result = mysqli_query($conn,$sql);
		  		while($row = mysqli_fetch_array($result))
		  		{
		  			echo '<option value="'.$row['author_email_address'].'">'.$row['name']." ".$row['lastname'].'</option>';
		  		}
		  	?>
		  </select>
		  <h6 style="text-align: left;">Journals:</h6>
		  <select name="journals">
		  	<?php
		  	$sql = "SELECT * FROM Journal";
		  	$result = mysqli_query($conn,$sql);
		  		while($row = mysqli_fetch_array($result))
		  		{
		  			echo '<option value="'.$row['ISSN'].'">'.$row['journal_name'].'</option>';
		  		}
		  	?>
		  </select>
		  	<input class="submitbutton" name="uploadpaper" type = "submit" value = " Upload Paper "/><br />
			<input class="submitbutton" name="submitpaper" type = "submit" value = " Submit Paper "/><br />

      <br><br><br>
	    </form>
	</div>
	    
			</div>


	  </div>












<div class="footer">
  <p></p>
</div>

</body>


</html>