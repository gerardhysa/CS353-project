<?php

  session_start();

   $servername = "dijkstra.ug.bcc.bilkent.edu.tr";
   $my_username = "busra.arabaci";
   $my_password = "n3j8zl6";
   $dbname = "busra_arabaci";

   $con = new mysqli($servername, $my_username, $my_password, $dbname);

   $success = FALSE;
   // Check connection
   if ($con->connect_error) {
       die("Connection failed: " . $con->connect_error);
   }
   //echo "Connected successfully";
   $success = TRUE;
   
   //Get author information
   $author_id = $_GET["author_id"];
   $author_sql = "SELECT * FROM author WHERE author_id='$author_id'";
   $author_result = $con->query($author_sql);
   $row = $author_result->fetch_assoc();
   $name = $row['name'];
   $lastname = $row['lastname'];


   //Read conferences from another table



   //See comments 
   //$comment_sql= "SELECT * FROM paper NATURAL JOIN comments";
  

?>

<html>
<head>
	<title>Scientific Paper Management System</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="stylesheet.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">

	<style type="text/css">
		
		.infobox {
		  width: 90%;
		  padding: 2%;
		  margin: auto;
		  position: relative;
		  
		  background: #FFFFFF;
		  /*max-width: 360px;*/
		  margin: 5% auto;
		  z-index: -1;
		  text-align: center;
		  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
		}

		textarea {
			width: 80%;
			height: 5%;
			margin: auto;
		}

	</style>

</head>

<body>

	<header>
		<h1>Scientific Paper Management System</h1>
		<p>Easiest way to read and publish scientific papers.</p>
	</header>

	<ul class="navlist">
		<li class="navitem"><a href="index.php">HOME</a></li>
		<li class="navitem"><a href="papers.php">PAPERS</a></li>
		<li class="navitem"><a href="authors.php">AUTHORS</a></li>
		<li class="navitem"><a href="#">INSTITUTIONS</a></li>
		<li class="navitem"><a href="#">CONFERENCES</a></li>
		<li class="navitem"><a href="#">PROFILE</a></li>
	</ul>

	<div class="search" style="display: block;">
		<button style="float: right;">Search</button>
		<input style="float: right;" type="text" name="Search">
		
	</div>


	<div class="infobox">

		<!--Print the information-->
		<?php
			echo "<h1>".$name."  ".$lastname."</h1>";
		?>

	


		<div class="commentsec">

			<!--Comment Feed-->

			<label>Enter Your Comment<br></label>
			<textarea name="comment"></textarea>

		</div>


	</div>






<div class="footer">
  <p></p>
</div>

</body>


</html>